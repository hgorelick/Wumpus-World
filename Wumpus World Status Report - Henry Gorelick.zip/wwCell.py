class Cell:
    def __init__(self, pos, map=None, percepts=(None, None, None, None, None), pit=False, wumpus=False):
        self.pos = pos
        self.percepts = tuple(percept for percept in percepts if percept is not None)
        self.stench = 'stench' in percepts
        self.breeze = 'breeze' in percepts
        self.glitter = 'glitter' in percepts

        self.pit = pit or 'pit' in percepts
        self.wumpus = wumpus or 'wumpus' in percepts
        self.explored = self.pos == (0, 3)

        self.map = map

    def __str__(self):
        return "room" + str(self.pos[0]) + str(self.pos[1])

    def set_map(self, map):
        self.map = map

    def update(self, percepts, pit, wumpus):
        self.stench = 'stench' in percepts
        self.breeze = 'breeze' in percepts
        self.glitter = 'glitter' in percepts
        self.pit = pit
        self.wumpus = wumpus

    def adjacents(self, tt=True):
        adjacent_positions = []
        if self.pos[0] + 1 <= 3:
            adjacent_positions.append((self.pos[0] + 1, self.pos[1]))
        if self.pos[0] - 1 >= 0:
            adjacent_positions.append((self.pos[0] - 1, self.pos[1]))
        if self.pos[1] + 1 <= 3:
            adjacent_positions.append((self.pos[0], self.pos[1] + 1))
        if self.pos[1] - 1 >= 0:
            adjacent_positions.append((self.pos[0], self.pos[1] - 1))

        adjacents = []
        for adjacent in adjacent_positions:
            if tt:
                for val in self.map[adjacent[0]][adjacent[1]].values():
                    adjacents.append(QueryCell(adjacent, self.map, val))
            else:
                adjacents.append(adjacent)
        if tt:
            adjacents = [cell for cell in adjacents if cell.pos != self.pos]
        else:
            adjacents = [pos for pos in adjacents if pos != self.pos]
        return adjacents

    def equals(self, qcell):
        return self.pos == qcell.pos and \
               self.__getattribute__(qcell.query) == qcell.truth_val

    def values(self):
        vals = []
        if self.stench:
            vals = ["stench"]
        if self.breeze:
            vals.append("breeze")
        if self.glitter:
            vals.append("glitter")
        if self.pit:
            vals.append("pit")
        if self.wumpus:
            vals.append("wumpus")
        return vals
    
    # @property
    # def safe(self):
    #     return not (self.pit or self.wumpus)

    def __eq__(self, other):
        return self.pos == other.pos and \
               self.stench == other.stench and \
               self.breeze == other.breeze and \
               self.glitter == other.glitter and \
               self.pit == other.pit and \
               self.wumpus == other.wumpus and \
               self.explored == other.explored

    def __ne__(self, other):
        return self.pos != other.pos or \
               self.stench != other.stench or \
               self.breeze != other.breeze or \
               self.glitter != other.glitter or \
               self.pit != other.pit or \
               self.wumpus != other.wumpus or \
               self.explored != other.explored

    def __hash__(self):
        return hash((self.pos, self.stench, self.breeze, self.glitter, self.pit, self.wumpus, self.explored))


# class StenchCell(Cell):
#     def __init__(self, pos):
#         super().__init__(pos)
#         self.value = True
#
#
# class BreezeCell(Cell):
#     def __init__(self, pos):
#         super().__init__(pos)
#         self.value = True


class QueryCell(Cell):
    def __init__(self, pos, map=None, percept=None, pit=False, wumpus=False):
        percepts = (percept, None, None, None, None) if percept is not None else (None, None, None, None, None)
        super().__init__(pos, map, percepts, pit, wumpus)
        self.query = 'pit' if self.pit else ('wumpus' if self.wumpus else percept)
        self.truth_val = True

    def negate_query(self):
        self.__setattr__(self.query, not self.__getattribute__(self.query))
        self.truth_val = False
        return self

    def __eq__(self, other):
        return self.pos == other.pos and \
               self.__getattribute__(self.query) == other.__getattribute__(self.query) and \
               self.truth_val == other.truth_val

    def __hash__(self):
        return hash((self.pos, self.__getattribute__(self.query), self.truth_val))
