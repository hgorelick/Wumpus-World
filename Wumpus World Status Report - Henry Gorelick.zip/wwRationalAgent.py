"""
Modified from wwagent.py written by Greg Scott

Modified to only do random motions so that this can be the base
for building various kinds of agent that work with the wwsim.py
wumpus world simulation -----  dml Fordham 2019

# FACING KEY:
#    0 = up
#    1 = right
#    2 = down
#    3 = left

# Actions
# 'move' 'grab' 'shoot' 'left' right'

"""

from random import randint
from copy import *
from wwCell import *

from itertools import combinations

ALL_PERCEPTS = ['stench', 'breeze', 'glitter', 'bump', 'scream']

# This is the class that represents an agent


class WWRationalAgent:

    def __init__(self):
        self.max = 4  # number of cells in one side of square world
        self.position = (3, 0)  # top is (0,0)
        self.last_position = (3, 0)
        self.directions = ['up', 'right', 'down', 'left']
        self.facing = 'right'
        self.arrow = 1
        self.percepts = (None, None, None, None, None)
        self.last_move = None

        self.map = self.create_map()

        self.map[self.position[0]][self.position[1]].explored = True

        self.kb = set()
        self.models = set()
        self.journey = {(3, 0): 1}

        print("New agent created")

    # @property
    # def at_dungeon_edge(self):
    #     return self.position[1] == 0

    # Add the latest percepts to list of percepts received so far
    # This function is called by the wumpus simulation and will
    # update the sensory data. The sensor data is placed into a
    # map structured KB for later use

    def update(self, percept):
        self.percepts = percept
        # [stench, breeze, glitter, bump, scream]
        if self.position[0] in range(self.max) and self.position[1] in range(self.max):
            self.map[self.position[0]][self.position[1]] = Cell(self.position, self.map, self.percepts)
            self.map[self.position[0]][self.position[1]].explored = True
            self.update_kb()
            self.gen_models_from_map()
        # puts the percept at the spot in the map where sensed

    # Since there is no percept for location, the agent has to predict
    # what location it is in based on the direction it was facing
    # when it moved

    def calculateNextPosition(self, action):
        self.last_position = self.position
        if self.facing == 'up':
            self.position = (min(self.max - 1, self.position[0] - 1), self.position[1])
        elif self.facing == 'down':
            self.position = (min(self.max - 1, self.position[0] + 1), self.position[1])
        elif self.facing == 'right':
            self.position = (self.position[0], min(self.max - 1, self.position[1] + 1))
        elif self.facing == 'left':
            self.position = (self.position[0], min(self.max - 1, self.position[1] - 1))
        self.map[self.position[0]][self.position[1]].explored = True
        self.last_move = 'move ' + self.facing
        return self.position

    # and the same is true for the direction the agent is facing, it also
    # needs to be calculated based on whether the agent turned left/right
    # and what direction it was facing when it did

    def calculateNextDirection(self, action):
        if self.facing == 'up':
            if action == 'left':
                self.facing = 'left'
            else:
                self.facing = 'right'
        elif self.facing == 'down':
            if action == 'left':
                self.facing = 'right'
            else:
                self.facing = 'left'
        elif self.facing == 'right':
            if action == 'left':
                self.facing = 'up'
            else:
                self.facing = 'down'
        elif self.facing == 'left':
            if action == 'left':
                self.facing = 'down'
            else:
                self.facing = 'up'
        self.last_move = 'rotated ' + self.facing

    # this is the function that will pick the next action of
    # the agent using truth table enumeration.

    def action(self):
        """
        Choose an action based on self.kb
        :return: a valid Wumpus World action
        """
        if 'glitter' in self.percepts:
            if self.last_move == 'picked up gold':
                action = 'climb'
            else:
                action = 'grab'
                self.last_move = 'picked up gold'
            print("Rational agent:", action)
            return action

        valid_moves = self.purge(self.get_possible_moves())
        unexplored = [move for move in valid_moves if not self.map[move[0]][move[1]].explored]
        if len(unexplored) == 0 and len(valid_moves) == 0:
            return self.exit_dungeon()

        if len(unexplored) > 0:
            next_pos = unexplored[0]
        elif len(valid_moves) > 1:
            next_pos = [move for move in valid_moves if move != self.last_position][0]
        else:
            next_pos = valid_moves[0]

        action = self.get_action(next_pos)

        if action == 'move':
            self.position = self.calculateNextPosition(action)
            if self.position in list(self.journey.keys()):
                self.journey[self.position] += 1
            else:
                self.journey[self.position] = 1
        else:
            self.calculateNextDirection(action)

        if all(val >= 3 for val in self.journey.values()):
            return self.exit_dungeon()

        print("Rational agent:", action, "-->", self.position[0], self.position[1], self.facing)
        return action

    # Truth Table Enumeration Methods
    def tt_entails(self, alpha):
        """
        Checks that self.map entails alpha
        :param alpha: a query for model checking.
                      Must be given as a list of QueryCell objects with the following:
                        - the position of the cell to check
                        - the single property of each cell in question set to True
                      Examples:
                        - [QueryCell((0, 0), tuple("stench")]
                            -> Checks that the cell at position (0, 0) has the stench percept
                        - [QueryCell((0, 0), pit=True)]
                            -> Checks whether the cell at position (0, 0) contains a pit
                        - [QueryCell((0, 0), tuple("breeze")),
                           QueryCell((1, 0), tuple("breeze")),
                           QueryCell((1, 1), pit=True)]
                            -> Checks whether cells at (0, 0) and (1, 0) have breezes,
                               and whether cell (1, 1) has a pit
        :return:
        """
        symbols = set(qcell for qcell in alpha)
        for cell in self.kb:
            for val in cell.values():
                qcell = QueryCell(cell.pos, map, val)
                if qcell not in symbols:
                    symbols.add(qcell)

        # query = self.create_map(True)
        # for qcell in symbols:
        #     query[qcell.pos[0]][qcell.pos[1]] = qcell

        return self.tt_checkall(alpha, symbols, set())

    def tt_checkall(self, alpha, symbols, model):
        def add(s, item):
            s.add(item)
            return s

        symbols = [symbol for symbol in symbols]
        if len(symbols) == 0:
            kb = [qcell for qcell in self.kb]
            kb += [qcell for qcell in self.models if qcell not in kb]
            if self.pl_true(kb, model):
                return self.pl_true(alpha, model)
            else:
                return True
        else:
            p = deepcopy(symbols[0])
            rest = deepcopy(symbols[1:])
            return self.tt_checkall(alpha, rest, add(model, p)) and \
                   self.tt_checkall(alpha, rest, add(model, p.negate_query()))

    @staticmethod
    def pl_true(query, model):
        holds = True
        for cell in query:
            for qcell in model:
                if cell.pos == qcell.pos:
                    if not cell.equals(qcell):
                        return False
        return holds

    # Helper Methods
    def create_map(self, query=False):
        if query:
            map = [[QueryCell((i, j), self.map, None) for i in range(self.max)] for j in range(self.max)]
        else:
            map = [[Cell((i, j), percepts=self.percepts) for j in range(self.max)] for i in range(self.max)]
        for row in map:
            for cell in row:
                cell.set_map(map)
        return map

    def update_kb(self):
        for val in self.percepts:
            self.kb.add(QueryCell((self.position[0], self.position[1]), self.map, val))

    def gen_models_from_map(self):
        wumpus_locations = []
        pit_locations = []
        for row in self.map:
            for cell in row:
                if cell.stench:
                    for pos in [pos for pos in cell.adjacents(False) if not self.map[pos[0]][pos[1]].explored]:
                        wumpus_locations.append(pos)
                if cell.breeze:
                    for pos in [pos for pos in cell.adjacents(False) if not self.map[pos[0]][pos[1]].explored]:
                        pit_locations.append(pos)

        if len(wumpus_locations) > 0:
            for i, w_pos in enumerate(wumpus_locations):
                self.models.add(QueryCell((w_pos[0], w_pos[1]), self.map, wumpus=True))
                for p_combo in list(combinations(pit_locations, i + 1)):
                    for p_pos in p_combo:
                        self.models.add(QueryCell((p_pos[0], p_pos[1]), self.map, pit=True))
        elif len(pit_locations) > 0:
            for i in range(len(pit_locations)):
                for combo in list(combinations(pit_locations, i + 1)):
                    for pos in combo:
                        self.models.add(QueryCell((pos[0], pos[1]), self.map, pit=True))

    def get_possible_moves(self):
        return [pos for pos in self.map[self.position[0]][self.position[1]].adjacents(False)]
        # if self.position[0] + 1 <= 3:
        #     possible_moves.append((self.position[0] + 1, self.position[1]))
        # if self.position[0] - 1 >= 0:
        #     possible_moves.append((self.position[0] - 1, self.position[1]))
        # if self.position[1] + 1 <= 3:
        #     possible_moves.append((self.position[0], self.position[1] + 1))
        # if self.position[1] - 1 >= 0:
        #     possible_moves.append((self.position[0], self.position[1] - 1))
        # return possible_moves

    def purge(self, possible_moves):
        """
        Removes "bad" moves from possible_moves through model checking for pits and wumpuses in adjacent cells
        :param possible_moves: a list of tuples specifying positions in Wumpus World
        :return: possible_moves with bad moves filtered out
        """
        bad_moves = []
        for move in possible_moves:
            if self.map[move[0]][move[1]].explored:
                continue
            adjacents = self.map[move[0]][move[1]].adjacents()
            if 'breeze' in self.percepts:
                if self.tt_entails(adjacents + [QueryCell(move, pit=True)]):
                    bad_moves.append(move)
            elif 'stench' in self.percepts:
                if self.tt_entails(adjacents + [QueryCell(move, wumpus=True)]):
                    bad_moves.append(move)
        return [move for move in possible_moves if move not in bad_moves]

    def get_action(self, next_pos):
        action = 'move'
        if self.facing == 'up' and next_pos == (self.position[0] - 1, self.position[1]) or \
           self.facing == 'down' and next_pos == (self.position[0] + 1, self.position[1]):
            return action
        elif self.position[1] == 0 and self.facing == 'left':
            if self.position[0] < next_pos[0]:
                action = 'left'
            else:
                action = 'right'
        elif self.position[1] == self.max - 1 and self.facing == 'right':
            if self.position[0] > next_pos[0]:
                action = 'left'
            else:
                action = 'right'
        elif self.position[0] < next_pos[0] or self.position[1] > next_pos[1]:
            action = 'move' if self.facing == 'left' else 'left'
        elif self.position[0] > next_pos[0] or self.position[1] < next_pos[1]:
            action = 'move' if self.facing == 'right' else 'right'

        return action

    @staticmethod
    def exit_dungeon():
        print("This dungeon is not safe! Climbing out...")
        return 'climb'

    # def is_safe(self, position):
    #     return self.map[position[0]][position[1]].safe
